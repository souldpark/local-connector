"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.container = void 0;
var inversify_1 = require("inversify");
var printer_controller_1 = require("../controllers/printer.controller");
var printer_service_1 = require("../services/printer.service");
var health_controller_1 = require("../controllers/health.controller");
var device_service_1 = require("../services/device.service");
var devices_controller_1 = require("../controllers/devices.controller");
var config_service_1 = require("../services/config.service");
var socket_service_1 = require("../services/socket.service");
var worker_service_1 = require("../services/worker.service");
var configuration_controller_1 = require("../controllers/configuration.controller");
var container = new inversify_1.Container();
exports.container = container;
container
    .bind(config_service_1.ConfigService.name)
    .to(config_service_1.ConfigService)
    .inSingletonScope();
container
    .bind(socket_service_1.SocketService.name)
    .to(socket_service_1.SocketService)
    .inSingletonScope();
container
    .bind(printer_service_1.PrinterService.name)
    .to(printer_service_1.PrinterService)
    .inSingletonScope();
container
    .bind(device_service_1.DeviceService.name)
    .to(device_service_1.DeviceService)
    .inSingletonScope();
container
    .bind(worker_service_1.WorkerService.name)
    .to(worker_service_1.WorkerService)
    .inSingletonScope();
container
    .bind(devices_controller_1.DeviceController.name)
    .to(devices_controller_1.DeviceController);
container
    .bind(printer_controller_1.PrinterController.name)
    .to(printer_controller_1.PrinterController);
container
    .bind(configuration_controller_1.ConfigurationController.name)
    .to(configuration_controller_1.ConfigurationController);
container
    .bind(health_controller_1.HealthController.name)
    .to(health_controller_1.HealthController);
